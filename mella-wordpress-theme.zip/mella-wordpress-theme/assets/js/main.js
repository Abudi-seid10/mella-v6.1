/**
 * Mella Counseling Center Theme JavaScript
 * 
 * @package Mella_Counseling
 * @version 1.0.0
 */

(function($) {
    'use strict';

    // Wait for DOM to be ready
    $(document).ready(function() {
        
        // Initialize all functionality
        initMobileMenu();
        initScrollEffects();
        initAnimations();
        initForms();
        
        // Initialize Lucide icons if available
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    });

    /**
     * Mobile Menu Toggle
     */
    function initMobileMenu() {
        const $mobileMenuButton = $('#mobile-menu-button');
        const $mobileMenu = $('#mobile-menu');
        
        if ($mobileMenuButton.length && $mobileMenu.length) {
            $mobileMenuButton.on('click', function() {
                $mobileMenu.toggleClass('hidden');
                
                // Animate hamburger menu
                const $spans = $mobileMenuButton.find('span');
                if ($mobileMenu.hasClass('hidden')) {
                    // Reset to hamburger
                    $spans.eq(0).css('transform', 'rotate(0deg) translateY(0px)');
                    $spans.eq(1).css('opacity', '1');
                    $spans.eq(2).css('transform', 'rotate(0deg) translateY(0px)');
                } else {
                    // Transform to X
                    $spans.eq(0).css('transform', 'rotate(45deg) translateY(8px)');
                    $spans.eq(1).css('opacity', '0');
                    $spans.eq(2).css('transform', 'rotate(-45deg) translateY(-8px)');
                }
            });

            // Close mobile menu when clicking on links
            $mobileMenu.find('a').on('click', function() {
                $mobileMenu.addClass('hidden');
                const $spans = $mobileMenuButton.find('span');
                $spans.eq(0).css('transform', 'rotate(0deg) translateY(0px)');
                $spans.eq(1).css('opacity', '1');
                $spans.eq(2).css('transform', 'rotate(0deg) translateY(0px)');
            });
        }
    }

    /**
     * Scroll Effects
     */
    function initScrollEffects() {
        const $nav = $('#main-navigation');
        const $backToTop = $('#back-to-top');

        // Navbar background on scroll
        $(window).on('scroll', function() {
            const scrollTop = $(window).scrollTop();
            
            if ($nav.length) {
                if (scrollTop > 50) {
                    $nav.css({
                        'background': 'rgba(255, 255, 255, 0.98)',
                        'box-shadow': '0 2px 10px rgba(0, 0, 0, 0.1)'
                    });
                } else {
                    $nav.css({
                        'background': 'rgba(255, 255, 255, 0.95)',
                        'box-shadow': 'none'
                    });
                }
            }

            // Back to top button
            if ($backToTop.length) {
                if (scrollTop > 300) {
                    $backToTop.removeClass('opacity-0 pointer-events-none').addClass('opacity-100');
                } else {
                    $backToTop.addClass('opacity-0 pointer-events-none').removeClass('opacity-100');
                }
            }
        });

        // Back to top functionality
        if ($backToTop.length) {
            $backToTop.on('click', function(e) {
                e.preventDefault();
                $('html, body').animate({ scrollTop: 0 }, 600);
            });
        }

        // Smooth scrolling for anchor links
        $('a[href^="#"]').on('click', function(e) {
            const href = $(this).attr('href');
            const $target = $(href);
            
            if ($target.length) {
                e.preventDefault();
                const offsetTop = $target.offset().top - 80; // Account for fixed nav
                
                $('html, body').animate({
                    scrollTop: offsetTop
                }, 600);
            }
        });
    }

    /**
     * Initialize Animations and Interactive Elements
     */
    function initAnimations() {
        // Intersection Observer for fade-in animations
        if ('IntersectionObserver' in window) {
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        $(entry.target).addClass('fade-in-up');
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);

            // Observe elements that should animate on scroll
            $('.service-card, .testimonial-card, .team-member').each(function() {
                observer.observe(this);
            });
        }

        // Hover effects for service cards
        $('.service-card').on('mouseenter', function() {
            $(this).find('.service-gradient-overlay').css('opacity', '1');
        }).on('mouseleave', function() {
            $(this).find('.service-gradient-overlay').css('opacity', '0');
        });
    }

    /**
     * Form Handling
     */
    function initForms() {
        // Newsletter form
        $('#newsletter-form').on('submit', function(e) {
            e.preventDefault();
            const $form = $(this);
            const email = $form.find('input[type="email"]').val();
            
            // Simple validation
            if (email && validateEmail(email)) {
                // Here you would typically send the email to your backend
                alert('Thank you for subscribing! We\'ll keep you updated with mental health tips and resources.');
                $form[0].reset();
            } else {
                alert('Please enter a valid email address.');
            }
        });

        // Contact form (if exists)
        $('#contact-form').on('submit', function(e) {
            e.preventDefault();
            const $form = $(this);
            const $submitBtn = $form.find('button[type="submit"]');
            
            // Show loading state
            $submitBtn.prop('disabled', true).text('Sending...');
            
            // Here you would typically send the form data via AJAX
            setTimeout(function() {
                alert('Thank you for your message! We\'ll get back to you within 24 hours.');
                $form[0].reset();
                $submitBtn.prop('disabled', false).text('Send Message');
            }, 1000);
        });
    }

    /**
     * Email validation helper
     */
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    /**
     * Testimonials Carousel (if needed)
     */
    function initTestimonialCarousel() {
        const $carousel = $('.testimonials-carousel');
        const $items = $carousel.find('.testimonial-item');
        const $prevBtn = $('.testimonials-prev');
        const $nextBtn = $('.testimonials-next');
        const $indicators = $('.testimonial-indicator');
        
        let currentIndex = 0;
        const itemCount = $items.length;
        
        if (itemCount <= 1) return;
        
        // Show testimonial
        function showTestimonial(index) {
            $items.removeClass('active');
            $indicators.removeClass('active');
            
            $items.eq(index).addClass('active');
            $indicators.eq(index).addClass('active');
        }
        
        // Next testimonial
        function nextTestimonial() {
            currentIndex = (currentIndex + 1) % itemCount;
            showTestimonial(currentIndex);
        }
        
        // Previous testimonial
        function prevTestimonial() {
            currentIndex = (currentIndex - 1 + itemCount) % itemCount;
            showTestimonial(currentIndex);
        }
        
        // Event listeners
        $nextBtn.on('click', nextTestimonial);
        $prevBtn.on('click', prevTestimonial);
        
        $indicators.on('click', function() {
            currentIndex = $(this).data('index');
            showTestimonial(currentIndex);
        });
        
        // Auto-play (optional)
        setInterval(nextTestimonial, 5000);
        
        // Initialize first testimonial
        showTestimonial(0);
    }

    /**
     * Lazy Loading Images
     */
    function initLazyLoading() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });

            document.querySelectorAll('img[data-src]').forEach(function(img) {
                imageObserver.observe(img);
            });
        }
    }

    // Initialize additional features when needed
    // initTestimonialCarousel();
    // initLazyLoading();

})(jQuery);
