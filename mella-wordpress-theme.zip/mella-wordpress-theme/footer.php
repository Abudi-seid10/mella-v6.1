<?php
/**
 * Footer Template
 * 
 * @package Mella_Counseling
 */

$phone = get_theme_mod('mella_phone', '+251 92 541 9100');
$email = get_theme_mod('mella_email', 'info@mellacounseling.com.et');
$address = get_theme_mod('mella_address', 'Addis Ababa, Ethiopia');
?>

<!-- Footer -->
<footer class="section section-bg-white" style="background: linear-gradient(135deg, var(--color-primary-50), var(--color-secondary-50));">
    <div class="container">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <!-- Contact Information -->
            <div class="text-center md:text-left">
                <div class="mb-6">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/mella_logo.png" alt="<?php bloginfo('name'); ?>" class="h-12 w-auto mx-auto md:mx-0 mb-4">
                    <?php endif; ?>
                    <h3 class="text-xl font-bold mb-2" style="color: var(--color-primary-700);">
                        <?php bloginfo('name'); ?>
                    </h3>
                    <p class="text-sm" style="color: var(--color-neutral-600);">
                        <?php bloginfo('description'); ?>
                    </p>
                </div>
                
                <div class="space-y-3">
                    <div class="flex items-center justify-center md:justify-start space-x-3">
                        <div class="w-5 h-5 rounded-full flex items-center justify-center" style="background-color: var(--color-primary-100);">
                            <i data-lucide="map-pin" class="w-3 h-3" style="color: var(--color-primary-600);"></i>
                        </div>
                        <span class="text-sm" style="color: var(--color-neutral-700);">
                            <?php echo esc_html($address); ?>
                        </span>
                    </div>
                    
                    <div class="flex items-center justify-center md:justify-start space-x-3">
                        <div class="w-5 h-5 rounded-full flex items-center justify-center" style="background-color: var(--color-primary-100);">
                            <i data-lucide="phone" class="w-3 h-3" style="color: var(--color-primary-600);"></i>
                        </div>
                        <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>" class="text-sm hover:underline" style="color: var(--color-neutral-700);">
                            <?php echo esc_html($phone); ?>
                        </a>
                    </div>
                    
                    <div class="flex items-center justify-center md:justify-start space-x-3">
                        <div class="w-5 h-5 rounded-full flex items-center justify-center" style="background-color: var(--color-primary-100);">
                            <i data-lucide="mail" class="w-3 h-3" style="color: var(--color-primary-600);"></i>
                        </div>
                        <a href="mailto:<?php echo esc_attr($email); ?>" class="text-sm hover:underline" style="color: var(--color-neutral-700);">
                            <?php echo esc_html($email); ?>
                        </a>
                    </div>
                    
                    <div class="flex items-center justify-center md:justify-start space-x-3">
                        <div class="w-5 h-5 rounded-full flex items-center justify-center" style="background-color: var(--color-primary-100);">
                            <i data-lucide="clock" class="w-3 h-3" style="color: var(--color-primary-600);"></i>
                        </div>
                        <span class="text-sm" style="color: var(--color-neutral-700);">
                            <?php _e('Mon-Sat: 8:00 AM - 6:00 PM', 'mella-counseling'); ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Quick Links -->
            <div class="text-center md:text-left">
                <h4 class="text-lg font-semibold mb-6" style="color: var(--color-primary-700);">
                    <?php _e('Quick Links', 'mella-counseling'); ?>
                </h4>
                
                <?php if (is_active_sidebar('footer-2')) : ?>
                    <?php dynamic_sidebar('footer-2'); ?>
                <?php else : ?>
                    <ul class="space-y-3">
                        <li>
                            <a href="<?php echo home_url(); ?>" class="text-sm hover:underline transition-colors duration-200" style="color: var(--color-neutral-600);">
                                <?php _e('Home', 'mella-counseling'); ?>
                            </a>
                        </li>
                        <li>
                            <a href="#about" class="text-sm hover:underline transition-colors duration-200" style="color: var(--color-neutral-600);">
                                <?php _e('About Us', 'mella-counseling'); ?>
                            </a>
                        </li>
                        <li>
                            <a href="#services" class="text-sm hover:underline transition-colors duration-200" style="color: var(--color-neutral-600);">
                                <?php _e('Our Services', 'mella-counseling'); ?>
                            </a>
                        </li>
                        <li>
                            <a href="#testimonials" class="text-sm hover:underline transition-colors duration-200" style="color: var(--color-neutral-600);">
                                <?php _e('Testimonials', 'mella-counseling'); ?>
                            </a>
                        </li>
                        <li>
                            <a href="#contact" class="text-sm hover:underline transition-colors duration-200" style="color: var(--color-neutral-600);">
                                <?php _e('Contact Us', 'mella-counseling'); ?>
                            </a>
                        </li>
                        <?php if (get_option('page_for_posts')) : ?>
                        <li>
                            <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="text-sm hover:underline transition-colors duration-200" style="color: var(--color-neutral-600);">
                                <?php _e('Blog & Resources', 'mella-counseling'); ?>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </div>
            
            <!-- Newsletter & Social -->
            <div class="text-center md:text-left">
                <h4 class="text-lg font-semibold mb-6" style="color: var(--color-primary-700);">
                    <?php _e('Stay Connected', 'mella-counseling'); ?>
                </h4>
                
                <?php if (is_active_sidebar('footer-3')) : ?>
                    <?php dynamic_sidebar('footer-3'); ?>
                <?php else : ?>
                    <div class="mb-6">
                        <p class="text-sm mb-4" style="color: var(--color-neutral-600);">
                            <?php _e('Subscribe to our newsletter for mental health tips and updates.', 'mella-counseling'); ?>
                        </p>
                        
                        <!-- Newsletter Form -->
                        <form class="flex flex-col sm:flex-row gap-2" id="newsletter-form">
                            <input 
                                type="email" 
                                placeholder="<?php _e('Enter your email', 'mella-counseling'); ?>" 
                                class="flex-1 px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                                style="border-color: var(--color-primary-200); focus:ring-color: var(--color-primary-500);"
                                required
                            >
                            <button 
                                type="submit" 
                                class="btn btn-primary"
                                style="background: var(--color-primary-600); padding: 0.5rem 1rem;"
                            >
                                <?php _e('Subscribe', 'mella-counseling'); ?>
                            </button>
                        </form>
                    </div>
                    
                    <!-- Social Media Links -->
                    <div>
                        <p class="text-sm mb-4" style="color: var(--color-neutral-600);">
                            <?php _e('Follow us on social media:', 'mella-counseling'); ?>
                        </p>
                        <div class="flex justify-center md:justify-start space-x-4">
                            <a href="#" class="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110" style="background-color: var(--color-primary-100);" aria-label="Facebook">
                                <i data-lucide="facebook" class="w-5 h-5" style="color: var(--color-primary-600);"></i>
                            </a>
                            <a href="#" class="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110" style="background-color: var(--color-primary-100);" aria-label="Twitter">
                                <i data-lucide="twitter" class="w-5 h-5" style="color: var(--color-primary-600);"></i>
                            </a>
                            <a href="#" class="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110" style="background-color: var(--color-primary-100);" aria-label="Instagram">
                                <i data-lucide="instagram" class="w-5 h-5" style="color: var(--color-primary-600);"></i>
                            </a>
                            <a href="#" class="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110" style="background-color: var(--color-primary-100);" aria-label="LinkedIn">
                                <i data-lucide="linkedin" class="w-5 h-5" style="color: var(--color-primary-600);"></i>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Footer Bottom -->
        <div class="border-t py-8" style="border-color: var(--color-primary-200);">
            <div class="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                <div class="text-center md:text-left">
                    <p class="text-sm gradient-text">
                        &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'mella-counseling'); ?>
                    </p>
                    <p class="text-xs mt-1" style="color: var(--color-neutral-500);">
                        <?php _e('Licensed and registered in Ethiopia. Confidential professional mental health services.', 'mella-counseling'); ?>
                    </p>
                </div>
                
                <div class="text-center md:text-right">
                    <p class="text-xs" style="color: var(--color-neutral-500);">
                        <?php _e('Developed by', 'mella-counseling'); ?> 
                        <a href="#" class="hover:underline" style="color: var(--color-accent-600);">
                            <?php _e('MoTech Solutions', 'mella-counseling'); ?>
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->
<button 
    id="back-to-top" 
    class="fixed bottom-8 right-8 w-12 h-12 rounded-full shadow-lg transition-all duration-300 opacity-0 pointer-events-none hover:scale-110"
    style="background: var(--color-primary-600); color: white; z-index: 40;"
    aria-label="<?php _e('Back to top', 'mella-counseling'); ?>"
>
    <i data-lucide="chevron-up" class="w-6 h-6 mx-auto"></i>
</button>

<?php wp_footer(); ?>

<!-- Initialize Lucide Icons -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
            
            // Animate hamburger menu
            const spans = mobileMenuButton.querySelectorAll('span');
            if (mobileMenu.classList.contains('hidden')) {
                spans[0].style.transform = 'rotate(0deg) translateY(0px)';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'rotate(0deg) translateY(0px)';
            } else {
                spans[0].style.transform = 'rotate(45deg) translateY(8px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translateY(-8px)';
            }
        });
    }
    
    // Back to top button
    const backToTop = document.getElementById('back-to-top');
    
    if (backToTop) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTop.classList.remove('opacity-0', 'pointer-events-none');
                backToTop.classList.add('opacity-100');
            } else {
                backToTop.classList.add('opacity-0', 'pointer-events-none');
                backToTop.classList.remove('opacity-100');
            }
        });
        
        backToTop.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
    
    // Newsletter form
    const newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            alert('<?php _e("Thank you for subscribing! We'll keep you updated.", 'mella-counseling'); ?>');
            this.reset();
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offsetTop = target.offsetTop - 80; // Account for fixed nav
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Navbar background on scroll
    const nav = document.getElementById('main-navigation');
    if (nav) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 50) {
                nav.style.background = 'rgba(255, 255, 255, 0.98)';
                nav.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            } else {
                nav.style.background = 'rgba(255, 255, 255, 0.95)';
                nav.style.boxShadow = 'none';
            }
        });
    }
});
</script>

</body>
</html>
