<?php
/**
 * Mella Counseling Center Theme Functions
 * 
 * @package Mella_Counseling
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Theme constants
define('MELLA_THEME_VERSION', '1.0.0');
define('MELLA_THEME_DIR', get_template_directory());
define('MELLA_THEME_URI', get_template_directory_uri());

/**
 * Theme Setup
 */
function mella_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script'
    ));
    add_theme_support('customize-selective-refresh-widgets');
    
    // Set up image sizes
    add_image_size('mella-hero', 800, 600, true);
    add_image_size('mella-service', 400, 300, true);
    add_image_size('mella-testimonial', 100, 100, true);
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'mella-counseling'),
        'footer' => __('Footer Menu', 'mella-counseling'),
    ));
}
add_action('after_setup_theme', 'mella_theme_setup');

/**
 * Enqueue Scripts and Styles
 */
function mella_enqueue_scripts() {
    // Enqueue theme stylesheet
    wp_enqueue_style('mella-style', get_stylesheet_uri(), array(), MELLA_THEME_VERSION);
    
    // Enqueue Lucide Icons (similar to what was used in React version)
    wp_enqueue_script('lucide-icons', 'https://unpkg.com/lucide@latest/dist/umd/lucide.js', array(), '1.0.0', true);
    
    // Enqueue theme JavaScript
    wp_enqueue_script('mella-scripts', MELLA_THEME_URI . '/assets/js/main.js', array('jquery'), MELLA_THEME_VERSION, true);
    
    // Add inline styles for dynamic content
    wp_add_inline_style('mella-style', mella_get_custom_css());
}
add_action('wp_enqueue_scripts', 'mella_enqueue_scripts');

/**
 * Custom CSS for theme customizer options
 */
function mella_get_custom_css() {
    $custom_css = '';
    
    // Get customizer values
    $primary_color = get_theme_mod('mella_primary_color', '#2D5530');
    $secondary_color = get_theme_mod('mella_secondary_color', '#7B9A7C');
    $accent_color = get_theme_mod('mella_accent_color', '#E6C46B');
    
    // Generate custom CSS
    $custom_css .= "
        :root {
            --color-primary-500: {$primary_color};
            --color-secondary-500: {$secondary_color};
            --color-accent-500: {$accent_color};
        }
    ";
    
    return $custom_css;
}

/**
 * Register Custom Post Types
 */
function mella_register_post_types() {
    // Services Post Type
    register_post_type('service', array(
        'labels' => array(
            'name' => __('Services', 'mella-counseling'),
            'singular_name' => __('Service', 'mella-counseling'),
            'add_new' => __('Add New Service', 'mella-counseling'),
            'add_new_item' => __('Add New Service', 'mella-counseling'),
            'edit_item' => __('Edit Service', 'mella-counseling'),
            'new_item' => __('New Service', 'mella-counseling'),
            'view_item' => __('View Service', 'mella-counseling'),
            'search_items' => __('Search Services', 'mella-counseling'),
            'not_found' => __('No services found', 'mella-counseling'),
            'not_found_in_trash' => __('No services found in Trash', 'mella-counseling'),
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'services'),
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'menu_icon' => 'dashicons-heart',
        'show_in_rest' => true,
    ));
    
    // Testimonials Post Type
    register_post_type('testimonial', array(
        'labels' => array(
            'name' => __('Testimonials', 'mella-counseling'),
            'singular_name' => __('Testimonial', 'mella-counseling'),
            'add_new' => __('Add New Testimonial', 'mella-counseling'),
            'add_new_item' => __('Add New Testimonial', 'mella-counseling'),
            'edit_item' => __('Edit Testimonial', 'mella-counseling'),
            'new_item' => __('New Testimonial', 'mella-counseling'),
            'view_item' => __('View Testimonial', 'mella-counseling'),
            'search_items' => __('Search Testimonials', 'mella-counseling'),
            'not_found' => __('No testimonials found', 'mella-counseling'),
            'not_found_in_trash' => __('No testimonials found in Trash', 'mella-counseling'),
        ),
        'public' => true,
        'has_archive' => false,
        'rewrite' => array('slug' => 'testimonials'),
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-format-quote',
        'show_in_rest' => true,
    ));
    
    // Team Members Post Type
    register_post_type('team_member', array(
        'labels' => array(
            'name' => __('Team Members', 'mella-counseling'),
            'singular_name' => __('Team Member', 'mella-counseling'),
            'add_new' => __('Add New Team Member', 'mella-counseling'),
            'add_new_item' => __('Add New Team Member', 'mella-counseling'),
            'edit_item' => __('Edit Team Member', 'mella-counseling'),
            'new_item' => __('New Team Member', 'mella-counseling'),
            'view_item' => __('View Team Member', 'mella-counseling'),
            'search_items' => __('Search Team Members', 'mella-counseling'),
            'not_found' => __('No team members found', 'mella-counseling'),
            'not_found_in_trash' => __('No team members found in Trash', 'mella-counseling'),
        ),
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-groups',
        'show_in_rest' => true,
    ));
}
add_action('init', 'mella_register_post_types');

/**
 * Add Meta Boxes for Custom Post Types
 */
function mella_add_meta_boxes() {
    // Service meta boxes
    add_meta_box(
        'service_details',
        __('Service Details', 'mella-counseling'),
        'mella_service_meta_box',
        'service',
        'normal',
        'high'
    );
    
    // Testimonial meta boxes
    add_meta_box(
        'testimonial_details',
        __('Testimonial Details', 'mella-counseling'),
        'mella_testimonial_meta_box',
        'testimonial',
        'normal',
        'high'
    );
    
    // Team member meta boxes
    add_meta_box(
        'team_member_details',
        __('Team Member Details', 'mella-counseling'),
        'mella_team_member_meta_box',
        'team_member',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'mella_add_meta_boxes');

/**
 * Service Meta Box Callback
 */
function mella_service_meta_box($post) {
    wp_nonce_field('mella_service_meta_box', 'mella_service_meta_box_nonce');
    
    $icon = get_post_meta($post->ID, '_service_icon', true);
    $features = get_post_meta($post->ID, '_service_features', true);
    $color_scheme = get_post_meta($post->ID, '_service_color_scheme', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th scope="row"><label for="service_icon"><?php _e('Icon', 'mella-counseling'); ?></label></th>
            <td>
                <select name="service_icon" id="service_icon">
                    <option value="Users" <?php selected($icon, 'Users'); ?>><?php _e('Users (Family)', 'mella-counseling'); ?></option>
                    <option value="User" <?php selected($icon, 'User'); ?>><?php _e('User (Individual)', 'mella-counseling'); ?></option>
                    <option value="Heart" <?php selected($icon, 'Heart'); ?>><?php _e('Heart (Play Therapy)', 'mella-counseling'); ?></option>
                    <option value="Palette" <?php selected($icon, 'Palette'); ?>><?php _e('Palette (Art Therapy)', 'mella-counseling'); ?></option>
                    <option value="Video" <?php selected($icon, 'Video'); ?>><?php _e('Video (Online)', 'mella-counseling'); ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="service_features"><?php _e('Features (one per line)', 'mella-counseling'); ?></label></th>
            <td>
                <textarea name="service_features" id="service_features" rows="5" cols="50"><?php echo esc_textarea($features); ?></textarea>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="service_color_scheme"><?php _e('Color Scheme', 'mella-counseling'); ?></label></th>
            <td>
                <select name="service_color_scheme" id="service_color_scheme">
                    <option value="blue" <?php selected($color_scheme, 'blue'); ?>><?php _e('Blue', 'mella-counseling'); ?></option>
                    <option value="green" <?php selected($color_scheme, 'green'); ?>><?php _e('Green', 'mella-counseling'); ?></option>
                    <option value="pink" <?php selected($color_scheme, 'pink'); ?>><?php _e('Pink', 'mella-counseling'); ?></option>
                    <option value="purple" <?php selected($color_scheme, 'purple'); ?>><?php _e('Purple', 'mella-counseling'); ?></option>
                    <option value="indigo" <?php selected($color_scheme, 'indigo'); ?>><?php _e('Indigo', 'mella-counseling'); ?></option>
                </select>
            </td>
        </tr>
    </table>
    <?php
}

/**
 * Testimonial Meta Box Callback
 */
function mella_testimonial_meta_box($post) {
    wp_nonce_field('mella_testimonial_meta_box', 'mella_testimonial_meta_box_nonce');
    
    $client_name = get_post_meta($post->ID, '_testimonial_client_name', true);
    $rating = get_post_meta($post->ID, '_testimonial_rating', true);
    $anonymous = get_post_meta($post->ID, '_testimonial_anonymous', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th scope="row"><label for="testimonial_client_name"><?php _e('Client Name', 'mella-counseling'); ?></label></th>
            <td>
                <input type="text" name="testimonial_client_name" id="testimonial_client_name" value="<?php echo esc_attr($client_name); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="testimonial_rating"><?php _e('Rating', 'mella-counseling'); ?></label></th>
            <td>
                <select name="testimonial_rating" id="testimonial_rating">
                    <option value="5" <?php selected($rating, '5'); ?>><?php _e('5 Stars', 'mella-counseling'); ?></option>
                    <option value="4" <?php selected($rating, '4'); ?>><?php _e('4 Stars', 'mella-counseling'); ?></option>
                    <option value="3" <?php selected($rating, '3'); ?>><?php _e('3 Stars', 'mella-counseling'); ?></option>
                    <option value="2" <?php selected($rating, '2'); ?>><?php _e('2 Stars', 'mella-counseling'); ?></option>
                    <option value="1" <?php selected($rating, '1'); ?>><?php _e('1 Star', 'mella-counseling'); ?></option>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="testimonial_anonymous"><?php _e('Anonymous', 'mella-counseling'); ?></label></th>
            <td>
                <input type="checkbox" name="testimonial_anonymous" id="testimonial_anonymous" value="1" <?php checked($anonymous, '1'); ?> />
                <label for="testimonial_anonymous"><?php _e('Display as anonymous testimonial', 'mella-counseling'); ?></label>
            </td>
        </tr>
    </table>
    <?php
}

/**
 * Team Member Meta Box Callback
 */
function mella_team_member_meta_box($post) {
    wp_nonce_field('mella_team_member_meta_box', 'mella_team_member_meta_box_nonce');
    
    $position = get_post_meta($post->ID, '_team_member_position', true);
    $credentials = get_post_meta($post->ID, '_team_member_credentials', true);
    $specialties = get_post_meta($post->ID, '_team_member_specialties', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th scope="row"><label for="team_member_position"><?php _e('Position/Title', 'mella-counseling'); ?></label></th>
            <td>
                <input type="text" name="team_member_position" id="team_member_position" value="<?php echo esc_attr($position); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="team_member_credentials"><?php _e('Credentials', 'mella-counseling'); ?></label></th>
            <td>
                <input type="text" name="team_member_credentials" id="team_member_credentials" value="<?php echo esc_attr($credentials); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="team_member_specialties"><?php _e('Specialties (one per line)', 'mella-counseling'); ?></label></th>
            <td>
                <textarea name="team_member_specialties" id="team_member_specialties" rows="5" cols="50"><?php echo esc_textarea($specialties); ?></textarea>
            </td>
        </tr>
    </table>
    <?php
}

/**
 * Save Meta Box Data
 */
function mella_save_meta_box_data($post_id) {
    // Check if our nonce is set and valid
    if (!isset($_POST['mella_service_meta_box_nonce']) && 
        !isset($_POST['mella_testimonial_meta_box_nonce']) && 
        !isset($_POST['mella_team_member_meta_box_nonce'])) {
        return;
    }
    
    // Verify nonce
    $nonce_verified = false;
    if (isset($_POST['mella_service_meta_box_nonce']) && wp_verify_nonce($_POST['mella_service_meta_box_nonce'], 'mella_service_meta_box')) {
        $nonce_verified = true;
    } elseif (isset($_POST['mella_testimonial_meta_box_nonce']) && wp_verify_nonce($_POST['mella_testimonial_meta_box_nonce'], 'mella_testimonial_meta_box')) {
        $nonce_verified = true;
    } elseif (isset($_POST['mella_team_member_meta_box_nonce']) && wp_verify_nonce($_POST['mella_team_member_meta_box_nonce'], 'mella_team_member_meta_box')) {
        $nonce_verified = true;
    }
    
    if (!$nonce_verified) {
        return;
    }
    
    // Check user permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    // Save service meta
    if (get_post_type($post_id) === 'service') {
        if (isset($_POST['service_icon'])) {
            update_post_meta($post_id, '_service_icon', sanitize_text_field($_POST['service_icon']));
        }
        if (isset($_POST['service_features'])) {
            update_post_meta($post_id, '_service_features', sanitize_textarea_field($_POST['service_features']));
        }
        if (isset($_POST['service_color_scheme'])) {
            update_post_meta($post_id, '_service_color_scheme', sanitize_text_field($_POST['service_color_scheme']));
        }
    }
    
    // Save testimonial meta
    if (get_post_type($post_id) === 'testimonial') {
        if (isset($_POST['testimonial_client_name'])) {
            update_post_meta($post_id, '_testimonial_client_name', sanitize_text_field($_POST['testimonial_client_name']));
        }
        if (isset($_POST['testimonial_rating'])) {
            update_post_meta($post_id, '_testimonial_rating', sanitize_text_field($_POST['testimonial_rating']));
        }
        if (isset($_POST['testimonial_anonymous'])) {
            update_post_meta($post_id, '_testimonial_anonymous', '1');
        } else {
            delete_post_meta($post_id, '_testimonial_anonymous');
        }
    }
    
    // Save team member meta
    if (get_post_type($post_id) === 'team_member') {
        if (isset($_POST['team_member_position'])) {
            update_post_meta($post_id, '_team_member_position', sanitize_text_field($_POST['team_member_position']));
        }
        if (isset($_POST['team_member_credentials'])) {
            update_post_meta($post_id, '_team_member_credentials', sanitize_text_field($_POST['team_member_credentials']));
        }
        if (isset($_POST['team_member_specialties'])) {
            update_post_meta($post_id, '_team_member_specialties', sanitize_textarea_field($_POST['team_member_specialties']));
        }
    }
}
add_action('save_post', 'mella_save_meta_box_data');

/**
 * Customizer Settings
 */
function mella_customize_register($wp_customize) {
    // Add Mella Settings Section
    $wp_customize->add_section('mella_settings', array(
        'title' => __('Mella Theme Settings', 'mella-counseling'),
        'priority' => 30,
    ));
    
    // Primary Color
    $wp_customize->add_setting('mella_primary_color', array(
        'default' => '#2D5530',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'mella_primary_color', array(
        'label' => __('Primary Color', 'mella-counseling'),
        'section' => 'mella_settings',
    )));
    
    // Secondary Color
    $wp_customize->add_setting('mella_secondary_color', array(
        'default' => '#7B9A7C',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'mella_secondary_color', array(
        'label' => __('Secondary Color', 'mella-counseling'),
        'section' => 'mella_settings',
    )));
    
    // Accent Color
    $wp_customize->add_setting('mella_accent_color', array(
        'default' => '#E6C46B',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'mella_accent_color', array(
        'label' => __('Accent Color', 'mella-counseling'),
        'section' => 'mella_settings',
    )));
    
    // Contact Information
    $wp_customize->add_setting('mella_phone', array(
        'default' => '+251 92 541 9100',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('mella_phone', array(
        'label' => __('Phone Number', 'mella-counseling'),
        'section' => 'mella_settings',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('mella_email', array(
        'default' => 'info@mellacounseling.com.et',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('mella_email', array(
        'label' => __('Email Address', 'mella-counseling'),
        'section' => 'mella_settings',
        'type' => 'email',
    ));
    
    $wp_customize->add_setting('mella_address', array(
        'default' => 'Addis Ababa, Ethiopia',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('mella_address', array(
        'label' => __('Business Address', 'mella-counseling'),
        'section' => 'mella_settings',
        'type' => 'text',
    ));
}
add_action('customize_register', 'mella_customize_register');

/**
 * Widget Areas
 */
function mella_widgets_init() {
    register_sidebar(array(
        'name' => __('Footer Widget Area 1', 'mella-counseling'),
        'id' => 'footer-1',
        'description' => __('Add widgets here to appear in your footer.', 'mella-counseling'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    
    register_sidebar(array(
        'name' => __('Footer Widget Area 2', 'mella-counseling'),
        'id' => 'footer-2',
        'description' => __('Add widgets here to appear in your footer.', 'mella-counseling'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    
    register_sidebar(array(
        'name' => __('Footer Widget Area 3', 'mella-counseling'),
        'id' => 'footer-3',
        'description' => __('Add widgets here to appear in your footer.', 'mella-counseling'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'mella_widgets_init');
