<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo get_bloginfo('description'); ?>">
    <meta name="keywords" content="mental health, counseling, therapy, Ethiopia, Addis Ababa, professional, licensed">
    <meta name="author" content="Mella Counseling Center">
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="<?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?>">
    <meta property="og:description" content="<?php echo get_bloginfo('description'); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo home_url(); ?>">
    <meta property="og:image" content="<?php echo get_template_directory_uri(); ?>/assets/images/mella-og-image.jpg">
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?>">
    <meta name="twitter:description" content="<?php echo get_bloginfo('description'); ?>">
    <meta name="twitter:image" content="<?php echo get_template_directory_uri(); ?>/assets/images/mella-twitter-card.jpg">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/assets/images/favicon.ico">
    
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Navigation -->
<nav class="fixed top-0 left-0 right-0 z-50 transition-all duration-300" id="main-navigation" style="background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(45, 85, 48, 0.1);">
    <div class="container">
        <div class="flex items-center justify-between py-4">
            <!-- Logo -->
            <div class="flex items-center">
                <a href="<?php echo home_url(); ?>" class="flex items-center space-x-3">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/mella_logo.png" alt="<?php bloginfo('name'); ?>" class="h-10 w-auto">
                    <?php endif; ?>
                    <span class="text-xl font-bold" style="color: var(--color-primary-600);">
                        <?php bloginfo('name'); ?>
                    </span>
                </a>
            </div>
            
            <!-- Desktop Navigation -->
            <div class="hidden lg:flex items-center space-x-8">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container' => false,
                    'menu_class' => 'flex items-center space-x-8',
                    'fallback_cb' => 'mella_default_menu',
                    'walker' => new Mella_Nav_Walker()
                ));
                ?>
                
                <!-- CTA Button -->
                <a href="#contact" class="btn btn-primary">
                    <?php _e('Get Support Today', 'mella-counseling'); ?>
                </a>
            </div>
            
            <!-- Mobile Menu Button -->
            <button class="lg:hidden" id="mobile-menu-button" aria-label="Toggle mobile menu">
                <div class="w-6 h-6 flex flex-col justify-center items-center">
                    <span class="w-6 h-0.5 bg-gray-600 transition-all duration-300 origin-center" style="background-color: var(--color-primary-600);"></span>
                    <span class="w-6 h-0.5 bg-gray-600 transition-all duration-300 origin-center mt-1.5" style="background-color: var(--color-primary-600);"></span>
                    <span class="w-6 h-0.5 bg-gray-600 transition-all duration-300 origin-center mt-1.5" style="background-color: var(--color-primary-600);"></span>
                </div>
            </button>
        </div>
        
        <!-- Mobile Navigation -->
        <div class="lg:hidden hidden" id="mobile-menu">
            <div class="py-4 border-t" style="border-color: rgba(45, 85, 48, 0.1);">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container' => false,
                    'menu_class' => 'flex flex-col space-y-4',
                    'fallback_cb' => 'mella_default_menu_mobile',
                ));
                ?>
                <a href="#contact" class="btn btn-primary w-full text-center mt-4">
                    <?php _e('Get Support Today', 'mella-counseling'); ?>
                </a>
            </div>
        </div>
    </div>
</nav>

<?php
/**
 * Custom Navigation Walker
 */
class Mella_Nav_Walker extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $output .= '<li' . $class_names .'>';
        
        $attributes = ! empty($item->attr_title) ? ' title="'  . esc_attr($item->attr_title) .'"' : '';
        $attributes .= ! empty($item->target)     ? ' target="' . esc_attr($item->target     ) .'"' : '';
        $attributes .= ! empty($item->xfn)        ? ' rel="'    . esc_attr($item->xfn        ) .'"' : '';
        $attributes .= ! empty($item->url)        ? ' href="'   . esc_attr($item->url        ) .'"' : '';
        
        $item_output = isset($args->before) ? $args->before : '';
        $item_output .= '<a' . $attributes . ' class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200">';
        $item_output .= (isset($args->link_before) ? $args->link_before : '') . apply_filters('the_title', $item->title, $item->ID) . (isset($args->link_after) ? $args->link_after : '');
        $item_output .= '</a>';
        $item_output .= isset($args->after) ? $args->after : '';
        
        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * Fallback menu for when no menu is assigned
 */
function mella_default_menu() {
    echo '<ul class="flex items-center space-x-8">';
    echo '<li><a href="' . home_url() . '" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200">' . __('Home', 'mella-counseling') . '</a></li>';
    echo '<li><a href="#about" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200">' . __('About Us', 'mella-counseling') . '</a></li>';
    echo '<li><a href="#services" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200">' . __('Services', 'mella-counseling') . '</a></li>';
    echo '<li><a href="#testimonials" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200">' . __('Testimonials', 'mella-counseling') . '</a></li>';
    echo '<li><a href="#contact" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200">' . __('Contact', 'mella-counseling') . '</a></li>';
    echo '</ul>';
}

function mella_default_menu_mobile() {
    echo '<div class="flex flex-col space-y-4">';
    echo '<a href="' . home_url() . '" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2">' . __('Home', 'mella-counseling') . '</a>';
    echo '<a href="#about" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2">' . __('About Us', 'mella-counseling') . '</a>';
    echo '<a href="#services" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2">' . __('Services', 'mella-counseling') . '</a>';
    echo '<a href="#testimonials" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2">' . __('Testimonials', 'mella-counseling') . '</a>';
    echo '<a href="#contact" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2">' . __('Contact', 'mella-counseling') . '</a>';
    echo '</div>';
}
?>
