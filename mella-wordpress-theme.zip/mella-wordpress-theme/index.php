<?php
/**
 * Main Index Template - renders homepage sections
 *
 * @package Mella_Counseling
 */

get_header();
?>

<!-- Hero Section -->
<section id="home" class="section section-bg-gradient" style="min-height: 90vh; position: relative; overflow: hidden;">
  <!-- Background Orbs -->
  <div style="position: absolute; inset: 0; z-index: 0;">
    <div style="position:absolute; top: 20%; left: 10%; width: 24rem; height: 24rem; background: linear-gradient(to bottom right, var(--color-primary-200), var(--color-secondary-200)); border-radius: 9999px; filter: blur(60px); opacity: .3;" class="animate-pulse-slow"></div>
    <div style="position:absolute; bottom: 15%; right: 15%; width: 20rem; height: 20rem; background: linear-gradient(to bottom right, var(--color-accent-200), var(--color-accent-300)); border-radius: 9999px; filter: blur(60px); opacity: .2;" class="animate-pulse-slow"></div>
  </div>

  <div class="container" style="position: relative; z-index: 1; padding-top: 8rem; padding-bottom: 4rem;">
    <div class="grid grid-cols-1 grid-cols-2">
      <div>
        <div class="inline-flex items-center gap-2 p-2 rounded-full shadow" style="background: rgba(255,255,255,0.8); border: 1px solid var(--color-primary-200);">
          <span style="color: var(--color-primary-600); font-weight: 600; font-size: .875rem;">Professional Mental Health Care</span>
        </div>

        <h1 class="mt-6" style="font-weight: 800; color: var(--color-neutral-900); line-height: 1.1;">
          <span style="font-size: clamp(2rem, 5vw, 3.5rem);">Your Path to <span class="gradient-text">Mental Wellness</span> Starts Here</span>
        </h1>

        <p class="mt-4" style="font-size: 1.125rem; color: var(--color-neutral-600); max-width: 42rem;">
          Compassionate, professional counseling services tailored to your unique journey. Take the first step towards healing and personal growth with our licensed therapists.
        </p>

        <div class="mt-8 flex gap-4">
          <a href="#contact" class="btn btn-primary">Start Your Journey</a>
          <a href="#services" class="btn btn-outline">Our Services</a>
        </div>

        <!-- Trust Indicators -->
        <div class="grid grid-cols-2 grid-cols-4 mt-12 gap-6">
          <?php
          $trust_indicators = [
            ['icon' => 'shield', 'text' => __('Licensed Professionals', 'mella-counseling'), 'count' => '100%'],
            ['icon' => 'users', 'text' => __('Happy Clients', 'mella-counseling'), 'count' => '500+'],
            ['icon' => 'lock', 'text' => __('Confidential', 'mella-counseling'), 'count' => '100%'],
            ['icon' => 'star', 'text' => __('Client Rating', 'mella-counseling'), 'count' => '4.9/5'],
          ];
          foreach ($trust_indicators as $indicator) : ?>
            <div class="text-center p-4 rounded-lg shadow" style="background: rgba(255,255,255,0.7); border: 1px solid var(--color-primary-100);">
              <i data-lucide="<?php echo esc_attr($indicator['icon']); ?>" class="w-6 h-6 mb-2" style="color: var(--color-primary-600);"></i>
              <div style="font-size: 1.5rem; font-weight: 700; color: var(--color-primary-700);" class="mb-1"><?php echo esc_html($indicator['count']); ?></div>
              <div style="font-size: .875rem; color: var(--color-neutral-600);"><?php echo esc_html($indicator['text']); ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Right Abstract Visual -->
      <div class="items-center justify-center" style="display:flex;">
        <div style="position: relative; width: 100%; max-width: 32rem; height: 24rem;">
          <div class="animate-float" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 8rem; height: 8rem; border-radius: 9999px; box-shadow: 0 25px 50px rgba(0,0,0,0.15); background: linear-gradient(to bottom right, var(--color-primary-500), var(--color-secondary-500)); display:flex; align-items:center; justify-content:center;">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/mella_white.png" alt="Mella Logo" style="width: 7rem; height: 7rem; object-fit: contain;" />
          </div>
          <!-- Orbiting dots -->
          <?php for ($i = 0; $i < 6; $i++) : $dur = 12 + $i * 2; ?>
            <div style="position:absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 4rem; height: 4rem; border-radius: 9999px; background: linear-gradient(to bottom right, var(--color-accent-400), var(--color-accent-600)); opacity:.8; box-shadow: 0 10px 20px rgba(0,0,0,.1); animation: spin <?php echo $dur; ?>s linear infinite;">
              <div style="width: 100%; height: 100%; border-radius: 9999px; background: linear-gradient(to bottom right, var(--color-accent-300), var(--color-accent-500)); display:flex; align-items:center; justify-content:center; transform-origin: 0 <?php echo 80 + $i * 20; ?>px; transform: translate(<?php echo 80 + $i * 20; ?>px, 0); animation: spin <?php echo $dur; ?>s linear infinite reverse;">
                <div style="width: .75rem; height: .75rem; background: white; border-radius: 9999px;"></div>
              </div>
            </div>
          <?php endfor; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Services Section -->
<section id="services" class="section section-bg-gradient" style="position:relative; overflow:hidden;">
  <div style="position:absolute; inset:0; pointer-events:none;">
    <div style="position:absolute; top: 20%; right: 0; width: 24rem; height: 24rem; background: linear-gradient(to bottom right, var(--color-primary-100), var(--color-secondary-100)); border-radius: 9999px; filter: blur(60px); opacity:.3; transform: translateX(50%);"></div>
    <div style="position:absolute; bottom: 20%; left: 0; width: 20rem; height: 20rem; background: linear-gradient(to bottom right, var(--color-accent-100), var(--color-accent-200)); border-radius: 9999px; filter: blur(60px); opacity:.25; transform: translateX(-50%);"></div>
  </div>

  <div class="container" style="position:relative; z-index:1;">
    <div class="text-center mb-12">
      <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4" style="background: var(--color-primary-100); color: var(--color-primary-700); font-weight: 600; font-size: .875rem;">
        <i data-lucide="heart" class="w-4 h-4"></i>
        <span><?php _e('Our Services', 'mella-counseling'); ?></span>
      </div>
      <h2 style="font-size: clamp(1.75rem, 3.5vw, 2.5rem); font-weight: 800; color: var(--color-neutral-900);" class="mb-4">
        <?php _e('Comprehensive Mental Health', 'mella-counseling'); ?> <span class="gradient-text"><?php _e('Solutions', 'mella-counseling'); ?></span>
      </h2>
      <p style="font-size: 1.125rem; color: var(--color-neutral-600); max-width: 48rem; margin: 0 auto;">
        <?php _e('We offer a range of professional mental health services designed to meet you wherever you are in your journey toward wellness and personal growth.', 'mella-counseling'); ?>
      </p>
    </div>

    <div class="grid grid-cols-1 grid-cols-2 grid-cols-3">
      <?php
      // Query up to 6 services
      $services = new WP_Query(array(
        'post_type' => 'service',
        'posts_per_page' => 6,
        'orderby' => 'menu_order',
        'order' => 'ASC',
      ));
      if ($services->have_posts()) :
        while ($services->have_posts()) : $services->the_post();
          $icon = get_post_meta(get_the_ID(), '_service_icon', true) ?: 'user';
          $features_raw = get_post_meta(get_the_ID(), '_service_features', true);
          $features = array_filter(array_map('trim', explode("\n", (string) $features_raw)));
          $scheme = get_post_meta(get_the_ID(), '_service_color_scheme', true) ?: 'green';
          $colors = array(
            'blue' => ['#dbeafe', '#1d4ed8'],
            'green' => ['#dcfce7', '#16a34a'],
            'pink' => ['#fce7f3', '#db2777'],
            'purple' => ['#ede9fe', '#7c3aed'],
            'indigo' => ['#e0e7ff', '#4338ca'],
          );
          $bg = $colors[$scheme][0];
          $fg = $colors[$scheme][1];
      ?>
      <div class="group rounded-2xl p-8 shadow transition-all" style="background: white; border: 1px solid var(--color-neutral-100); position:relative; overflow:hidden;">
        <div style="position:absolute; inset:0; border-radius:1rem; background: linear-gradient(to bottom right, <?php echo $bg; ?>, <?php echo $fg; ?>); opacity:0; transition: opacity .3s;"></div>
        <div style="position:absolute; inset:1px; border-radius:1rem; background: white;"></div>
        <div style="position:relative; z-index:1;">
          <div style="width: 4rem; height: 4rem; background: <?php echo $bg; ?>; border-radius: .75rem; display:flex; align-items:center; justify-content:center; margin-bottom: 1.5rem;">
            <i data-lucide="<?php echo esc_attr(strtolower($icon)); ?>" class="w-7 h-7" style="color: <?php echo $fg; ?>;"></i>
          </div>
          <h3 style="font-size:1.5rem; font-weight:800; color: var(--color-neutral-900); margin-bottom: 1rem;">
            <?php the_title(); ?>
          </h3>
          <div style="color: var(--color-neutral-600);" class="mb-6">
            <?php the_excerpt(); ?>
          </div>
          <?php if ($features) : ?>
          <div class="mb-6">
            <?php foreach ($features as $f) : ?>
              <div class="flex items-center gap-2 mb-2">
                <div style="width: .375rem; height: .375rem; background: var(--color-primary-500); border-radius: 9999px;"></div>
                <span style="font-size: .875rem; color: var(--color-neutral-700);"><?php echo esc_html($f); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <a href="<?php echo esc_url(get_post_type_archive_link('service')); ?>" class="text-sm" style="font-weight:600; color: var(--color-primary-600);">
            <?php _e('Learn More', 'mella-counseling'); ?> →
          </a>
        </div>
      </div>
      <?php endwhile; wp_reset_postdata(); else : ?>
        <p class="text-center" style="color: var(--color-neutral-600);">
          <?php _e('Add some services in the admin to display them here.', 'mella-counseling'); ?>
        </p>
      <?php endif; ?>
    </div>

    <!-- Bottom CTA -->
    <div class="text-center mt-16">
      <div class="p-8 rounded-2xl" style="background: linear-gradient(to right, var(--color-primary-50), var(--color-secondary-50)); border:1px solid var(--color-primary-100);">
        <h3 style="font-size:1.5rem; font-weight:800; color: var(--color-neutral-900);" class="mb-4"><?php _e('Not sure which service is right for you?', 'mella-counseling'); ?></h3>
        <p style="color: var(--color-neutral-600); max-width: 40rem; margin: 0 auto;" class="mb-6"><?php _e('Our experienced professionals are here to help you find the perfect approach for your unique needs. Schedule a consultation to discuss your goals and get personalized recommendations.', 'mella-counseling'); ?></p>
        <div class="flex items-center justify-center gap-4">
          <a class="btn btn-outline" href="<?php echo esc_url(get_post_type_archive_link('service')); ?>"><?php _e('View All Services', 'mella-counseling'); ?></a>
          <a class="btn btn-primary" href="#contact"><?php _e('Schedule Consultation', 'mella-counseling'); ?></a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
