# 🌿 Mella Counseling Center - WordPress Theme

A professional, modern WordPress theme designed specifically for mental health counseling practices. This theme is a faithful conversion of the original Next.js website, bringing the same beautiful design and functionality to WordPress.

![WordPress](https://img.shields.io/badge/WordPress-5.0+-blue?style=for-the-badge&logo=wordpress)
![PHP](https://img.shields.io/badge/PHP-7.4+-777BB4?style=for-the-badge&logo=php)
![License](https://img.shields.io/badge/License-GPL%20v2+-red?style=for-the-badge)

## 🎨 Design Features

**Professional Mental Health Color Palette:**
- **Primary:** Deep Forest Green (#2D5530) - Trust, growth, healing
- **Secondary:** Warm Sage Green (#7B9A7C) - Calmness, natural wellness  
- **Accent:** Soft Gold (#E6C46B) - Warmth, hope, optimism
- **Neutral:** Clean whites and soft grays - Professional accessibility

## ✨ Key Features

### 🏠 Homepage Sections
- **Hero Section** - Professional badge, compelling headline, trust indicators, animated logo
- **Services Grid** - Dynamic service cards with icons, features, and color schemes
- **Why Choose Us** - Key differentiators with engaging visuals
- **Testimonials Carousel** - Client testimonials with ratings and anonymous options
- **Call-to-Action** - Strategic placement for conversions

### 🛠️ WordPress Functionality
- **Custom Post Types:** Services, Testimonials, Team Members
- **Theme Customizer:** Colors, contact info, social links
- **Custom Fields:** Service icons, features, testimonial ratings
- **Responsive Design:** Mobile-first approach with smooth animations
- **SEO Optimized:** Proper meta tags, schema markup ready
- **Performance Focused:** Optimized CSS and JavaScript

### 📱 Technical Features
- **Modern CSS:** Custom properties, flexbox, grid layouts
- **Interactive Elements:** Hover effects, smooth transitions, Lucide icons
- **Mobile Navigation:** Animated hamburger menu with smooth toggles
- **Scroll Effects:** Dynamic navbar, back-to-top button, smooth scrolling
- **Form Handling:** Newsletter signup, contact forms with validation

## 🚀 Installation

### Requirements
- WordPress 5.0 or later
- PHP 7.4 or later
- Modern web browser with CSS Grid support

### Installation Steps

1. **Download & Upload**
   ```bash
   # Download the theme folder
   # Upload to: wp-content/themes/mella-wordpress-theme/
   ```

2. **Activate Theme**
   - Go to **WordPress Admin → Appearance → Themes**
   - Find "Mella Counseling Center" and click **Activate**

3. **Import Sample Content (Optional)**
   - Go to **Tools → Import** to add sample services and testimonials

4. **Setup Menus**
   - Go to **Appearance → Menus**
   - Create a new menu and assign it to "Primary Menu" location

5. **Customize Settings**
   - Go to **Appearance → Customize → Mella Theme Settings**
   - Configure colors, contact information, and other options

## ⚙️ Configuration

### Theme Customizer Options

Navigate to **Appearance → Customize → Mella Theme Settings**:

- **Primary Color:** Main brand color for headers, buttons, links
- **Secondary Color:** Supporting color for accents and backgrounds  
- **Accent Color:** Highlight color for special elements
- **Phone Number:** Business contact number (with Ethiopia format)
- **Email Address:** Professional contact email
- **Business Address:** Physical location (default: Addis Ababa, Ethiopia)

### Custom Post Types

#### 🧡 Services
- **Title:** Service name (e.g., "Family Counseling")
- **Content:** Detailed service description
- **Excerpt:** Short description for cards
- **Featured Image:** Service illustration
- **Custom Fields:**
  - Icon: Choose from Users, User, Heart, Palette, Video
  - Features: List key benefits (one per line)
  - Color Scheme: Blue, Green, Pink, Purple, Indigo

#### 💬 Testimonials
- **Title:** Testimonial title or client identifier
- **Content:** Full testimonial text
- **Featured Image:** Client photo (optional)
- **Custom Fields:**
  - Client Name: Real or anonymous name
  - Rating: 1-5 stars
  - Anonymous: Checkbox for privacy protection

#### 👥 Team Members
- **Title:** Team member name
- **Content:** Biography and background
- **Featured Image:** Professional photo
- **Custom Fields:**
  - Position/Title: Job role
  - Credentials: Degrees, certifications
  - Specialties: Areas of expertise

### Widget Areas

The theme includes 3 footer widget areas:

- **Footer Widget Area 1:** Contact information and branding
- **Footer Widget Area 2:** Quick navigation links
- **Footer Widget Area 3:** Newsletter signup and social media

## 🎯 Customization Guide

### Adding New Services

1. Go to **Services → Add New Service**
2. Fill in title, description, and excerpt
3. Add a featured image (400x300px recommended)
4. Configure custom fields:
   ```
   Icon: Users (for family counseling)
   Features: 
   Family Communication
   Conflict Resolution
   Relationship Building
   Emotional Support
   
   Color Scheme: Green
   ```
5. Publish the service

### Customizing Colors

1. **Via Customizer (Recommended):**
   - Go to **Appearance → Customize → Mella Theme Settings**
   - Use color pickers to adjust brand colors
   - Changes apply site-wide automatically

2. **Via CSS (Advanced):**
   ```css
   :root {
     --color-primary-500: #2D5530;   /* Your primary color */
     --color-secondary-500: #7B9A7C; /* Your secondary color */
     --color-accent-500: #E6C46B;    /* Your accent color */
   }
   ```

### Adding Custom CSS

1. Go to **Appearance → Customize → Additional CSS**
2. Add your custom styles:
   ```css
   /* Example: Custom button styles */
   .btn-custom {
     background: linear-gradient(135deg, #2D5530, #7B9A7C);
     color: white;
     border-radius: 50px;
     padding: 1rem 2rem;
   }
   
   /* Example: Service card modifications */
   .service-card {
     border: 2px solid var(--color-primary-200);
   }
   ```

## 🔧 Development

### File Structure
```
mella-wordpress-theme/
├── style.css              # Main stylesheet with theme header
├── functions.php          # Theme functionality and setup
├── header.php            # HTML head and navigation
├── footer.php            # Footer content and scripts
├── index.php             # Homepage template
├── assets/
│   ├── css/              # Additional stylesheets
│   ├── js/
│   │   └── main.js       # Theme JavaScript
│   └── images/
│       ├── mella_logo.png
│       └── mella_white.png
└── README.md             # This file
```

### Key Functions

#### `functions.php` includes:
- Theme setup and configuration
- Custom post type registration
- Meta boxes for custom fields
- Enqueue scripts and styles
- Theme customizer options
- Widget area registration

#### JavaScript Features (`main.js`):
- Mobile menu toggle with animations
- Smooth scrolling for anchor links
- Dynamic navbar background on scroll
- Back-to-top button functionality
- Form handling and validation
- Scroll-triggered animations

### Hooks & Filters

The theme uses standard WordPress hooks:
- `after_setup_theme` - Theme setup
- `wp_enqueue_scripts` - Load styles and scripts
- `init` - Register custom post types
- `customize_register` - Theme customizer options
- `widgets_init` - Register widget areas

## 🌍 Localization

The theme is translation-ready with text domain `mella-counseling`.

### Adding Translations

1. Use tools like Poedit or Loco Translate
2. Create language files for your locale:
   - `mella-counseling-es_ES.po` (Spanish)
   - `mella-counseling-am.po` (Amharic)
   - `mella-counseling-fr_FR.po` (French)

### Translatable Strings Include:
- Navigation menu items
- Button text and CTAs
- Form labels and placeholders
- Footer content
- Service features and descriptions

## 📱 Responsive Breakpoints

The theme uses mobile-first responsive design:

```css
/* Mobile First (default) */
@media (max-width: 480px)  { /* Small mobile */ }
@media (max-width: 768px)  { /* Mobile/tablet */ }
@media (max-width: 1024px) { /* Tablet */ }
@media (min-width: 1025px) { /* Desktop */ }
```

## 🔒 Security & Best Practices

- Sanitized and validated all user inputs
- Escaped all output using WordPress functions
- Nonce verification for form submissions
- Capability checks for admin functions
- XSS protection throughout
- SQL injection prevention

## 🧪 Testing

### Browser Compatibility
- ✅ Chrome 90+
- ✅ Firefox 85+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Mobile browsers

### WordPress Compatibility
- ✅ WordPress 5.0+
- ✅ Gutenberg Editor
- ✅ Classic Editor
- ✅ Multisite installations

## 🛠️ Troubleshooting

### Common Issues

**Icons not displaying:**
- Ensure Lucide icons library is loading
- Check browser console for JavaScript errors

**Animations not working:**
- Verify CSS animations are supported
- Check for JavaScript conflicts with other plugins

**Mobile menu not responsive:**
- Clear any caching plugins
- Check for CSS conflicts in browser dev tools

**Colors not changing:**
- Clear browser cache after customizer changes
- Verify CSS custom properties support

## 📞 Support

### Documentation
- WordPress Codex: https://codex.wordpress.org/
- Theme Development: https://developer.wordpress.org/themes/

### Customization Help
For theme customization and development assistance, refer to:
- WordPress Developer Resources
- CSS Grid and Flexbox guides
- JavaScript and jQuery documentation

## 📄 License

This theme is licensed under GPL v2 or later.
- Theme: GPL v2 or later
- Lucide Icons: ISC License
- Inter Font: SIL Open Font License

## 👨‍💻 Credits

**Developed by MoTech Solutions**
- Professional WordPress theme development
- Specialized in healthcare and mental health websites
- Focus on accessibility, performance, and user experience

**Original Design:** Based on the Mella Counseling Center Next.js website
**Conversion:** Next.js to WordPress theme adaptation
**Target:** Ethiopian mental health counseling practices

---

**Mella Counseling Center WordPress Theme** - Bringing professional, compassionate mental health care to the web with modern design and WordPress flexibility.
